# PyToolbox

A sidebar panel for Windows. It sits pinned to the left of the desktop, under
every other window, and it does not do any work itself — each row starts a tool
in its own process, and the pages behind the arrows hold the things I press
every day.

There are **two builds, and they are not the same file**. The desktop one and
the laptop one differ on purpose, and the differences are switched on a hostname
check rather than kept in two forks.

| | `laptop/toolbox.py` | `desktop/toolbox.py` |
|---|---|---|
| Disk readout | C only | C and E |
| GAME MODE button | yes | no |
| RELAUNCH button | no | yes |
| Priority sweep | follows GAME MODE, boosts and tames | always on, boosts only |
| Page 6 | desktop screen control | window layout slots A–G |

## The pages

1. Launchers — one row per tool, press again to close it
2. END TASK
3. OPEN
4. Repair
5. Accounts — reads `accounts.txt` next to the script, one `name | password` per line
6. Per machine, see the table above
7. 護眼 — dark mode, night shift, true tone, brightness

## Page 7

Dark mode, a night shift and a true tone toggle, and five brightness steps.

The dimming is done by bending the display gamma curve, not by touching the
backlight. A plain multiply is refused by Windows the moment warm and dim are
both on — the driver rejects any ramp entry sitting more than 32768 away from
the straight line. A power curve drops the midtones hard while the white point
barely moves, so the screen reads much darker and every entry stays inside what
Windows accepts. Because the backlight never moves, a PWM panel cannot start
flickering at low brightness, which is the usual reason dimming makes eyes worse
instead of better.

The table is read back once a second and only rewritten when something else has
replaced it, so going fullscreen in a game does not quietly switch it off, and
there is no flicker from writing a value that is already there.

## Running it

Python 3.12 with `psutil`. Start it with `pythonw.exe`, not `python.exe`, or you
get a console window behind it.

```
pythonw.exe toolbox.py
```

It writes `toolbox_boot.log` next to itself on every start and on any fatal
error. It runs under a single-instance mutex, so a second copy exits instead of
drawing a second panel.

## What to change before you run it

Both files carry my machine layout. The values below are placeholders in this
repo and are the only things you need to touch:

- `IS_DESKTOP` — the hostname prefix that decides which build you are on
- `SSH_HOST` and `SSH_KEY` — only used by the buttons that reach the other machine
- The tool paths in `TOOLS` and `OPEN_APPS`

## Notes

The panel pushes itself to the bottom of the window order every three seconds.
If it looks like it did not open, it is usually open and buried — check for a
`pythonw` process first, then read `toolbox_boot.log`.

Every failure is shown on the panel itself. Nothing here reports success into a
console you are not watching.
